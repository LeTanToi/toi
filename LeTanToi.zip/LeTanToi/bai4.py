print ("Bạn hãy nhập mật khẩu mới: ")
mk1 = input()
print ("bạn hãy nhập xác nhận mật khẩu mới lần 2")
mk2 = input()
if mk1==mk2:
    print("mật khẩu đã được đổi thành công")
else:
    print("Mật khẩu không giống nhau rồi")