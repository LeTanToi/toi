N = int(input("Năm dương lịch: "))
if (N%4==0 and N%100 !=0) or (N%400==0):
    print (f"năm {N} là năm nhuận")
else:
    print (f"Năm {N} không phải là năm nhuận")